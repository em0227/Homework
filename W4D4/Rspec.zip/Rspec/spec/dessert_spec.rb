require 'rspec'
require 'dessert'

=begin
Instructions: implement all of the pending specs (the `it` statements without blocks)! Be sure to look over the solutions when you're done.
=end

describe Dessert do
  let(:chef) { double("Em")}#, titleize => "Chef Emily the Great Baker") } #try to put the method here but won't work
  let(:test) { Dessert.new('brownie', 50, 'Emily')}

  describe "#initialize" do
    
    it "sets a type" do
      expect(test.type).to eq('brownie')
    end

    it "sets a quantity" do
      expect(test.quantity).to eq(50)
    end

    it "starts ingredients as an empty array" do
      expect(test.ingredients).to be_empty
    end

    it "raises an argument error when given a non-integer quantity" do
      expect { Dessert.new('cake', 'ten', 'Em')}.to raise_error(ArgumentError)
    end
  end

  describe "#add_ingredient" do
    it "adds an ingredient to the ingredients array" do
      test.add_ingredient('chocolate')
      expect(test.ingredients).to eq(['chocolate']) 
    end
  end

  describe "#mix!" do
    it "shuffles the ingredient array" do
      test.add_ingredient('chocolate')
      test.add_ingredient('milk')
      test.add_ingredient('flour')
      original_ingre = test.ingredients
      expect(test.mix!).to_not eq(original_ingre) 
    end
  end

  describe "#eat" do
    it "subtracts an amount from the quantity" do
      test.eat(20)
      expect(test.quantity).to eq(30)
    end

    it "raises an error if the amount is greater than the quantity" do 
      test.eat(60)
      expect {test.quantity}.to raise_exception #("not enough left!")   
    end

  end

  describe "#serve" do
    it "contains the titleized version of the chef's name" do
      allow(chef).to receive(:titleize).and_return('Chef Emily the Great Baker')
      expect(test.serve).to eq("Chef Emily the Great Baker has made 50 brownies!")
    end

  end

  describe "#make_more" do
    it "calls bake on the dessert's chef with the dessert passed in"
  end
end
